def luas_lingkaran(radius):
    pi = 22 / 7
    return pi * radius * radius