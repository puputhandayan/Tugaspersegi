def luas_persegi(sisi):
    return sisi * sisi